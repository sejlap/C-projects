﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    class Program
    {
        static void Main(string[] args)
        {
            Form form = new Form();
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Size = new Size(350, 200);
            form.Text = "Prvi parcijalni ispit";
            form.BackColor = Color.White;
            form.ForeColor = Color.Black;
            form.Font = new Font("Times New Roman", 11, FontStyle.Regular);

            GroupBox groupBox = new GroupBox();
            groupBox.Dock = DockStyle.Fill;
            groupBox.Text = "Pregled hijerarhije klasa";
            form.Controls.Add(groupBox);

            Label label1 = new Label();
            label1.Size = new Size(280, 25);
            label1.Text = "Predstave";
            label1.Location = new Point(5, 25);
            label1.BackColor = Color.Blue;
            form.Font = new Font("Consolas", 11, FontStyle.Regular);
            groupBox.Controls.Add(label1);


        }
    }
}
