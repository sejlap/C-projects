﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    public class StudisjkiProgrami
    {
        String Nazivpred { get; set;  }
        String Nazivprof { get; set; }
        int Brojpred { get; set; }
        int Brojvjezbi { get; set; }
        int Brojtut { get; set; }
        int Brojpoena { get; set; }

        public StudisjkiProgrami(string nazivpred, string nazivprof, int brojpred, int brojvjezbi, int brojtut, int brojpoena)
        {
            Nazivpred = nazivpred;
            Nazivprof = nazivprof;
            Brojpred = brojpred;
            Brojvjezbi = brojvjezbi;
            Brojtut = brojtut;
            Brojpoena = brojpoena;
        }
    }
}
