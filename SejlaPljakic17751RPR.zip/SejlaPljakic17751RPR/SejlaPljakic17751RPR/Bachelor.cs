﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    public class Bachelor  : RPRFaculty
    {
        internal object Id;

        int titula { get; set; }

        public Bachelor(String naziv, short id, int brojGodina, int predmeti, int titula)  : base( naziv,  id, brojGodina,  predmeti)
        {
        
            this.titula = titula;
        }
    }
}
