﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
   public abstract class RPRFaculty
    {
        static Int16 globalID;
        String naziv { get ; set; }
        Int16 id { get; set; }
        int brojGodina { get; set; }
        int predmeti { get; set; }

        public RPRFaculty(string naziv, short id, int brojGodina, int predmeti)
        {
          this.naziv = naziv;
          this.brojGodina = brojGodina;
          this.predmeti = predmeti;
            this.id = id;
            globalID += 1;

        }

        //  public abstract void ObracunaCijenu();


    }
}
