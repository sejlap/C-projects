﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    public class PhD : RPRFaculty
    {
        int istrazGrupe { get; set; }

        public PhD(string naziv, short id, int brojGodina, int predmeti,int istrazGrupe) : base(naziv,  id, brojGodina,predmeti)
        {
            this.istrazGrupe = istrazGrupe;
        }
    }
}
