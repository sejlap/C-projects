﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
   public  class IzborniPredmet :  StudisjkiProgrami
    {
        String status { get; set; }
        int Min;
        int Max;
        public IzborniPredmet(string nazivpred, string nazivprof, int brojpred, int brojvjezbi, int brojtut, int brojpoena, string status, int Min,int Max) : base( nazivpred,  nazivprof,  brojpred,  brojvjezbi,  brojtut,  brojpoena)
        {
            this.status = status;
            this.Min = Min;
            this.Max = Max;
        }
    }



}
