﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    public class Studiji
    {

        public List<Bachelor> studentiBachelora;
        public List<Master> studentiMastera;
        public List<PhD> studentiPhD;
        int Id;
        String Naziv;
        //  delegate void DelegatZaBrisanjePacijenta(string MaticniBroj);

        public Studiji()
        {
            studentiBachelora = new List<Bachelor>();
            studentiMastera = new List<Master>();
            studentiPhD = new List<PhD>();
      
        }


        public void ObjaviId(Int16 ID)
        {
            for (int i = 0; i < 3; i++)
            {
               // studentiBachelora.Find(studentiBachelora.Find(x => x.Id.Equals("LKT")));
                ID.ToString().CompareTo("LKT");

            }
        }
            public void PretraziId()
            {
                studentiBachelora.Find(studentiBachelora.Find(x => x.Id.ToString().));
                Id.ToString().CompareTo("LKT");
                
            }
        public void PretrazPoNazivuPredmeta(String nekipredmet)
        {
            if(Naziv.Find.)
        }
       



        }
    }
