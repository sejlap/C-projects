﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SejlaPljakic17751RPR
{
    public class Master : RPRFaculty
    {
       String studijskiProgrami { get; set; }

        public Master(string naziv, short id, int brojGodina, int predmeti,string studijskiProgrami) : base(naziv, id,  brojGodina, predmeti)
        {
            this.studijskiProgrami = studijskiProgrami;
        }

    }
}
